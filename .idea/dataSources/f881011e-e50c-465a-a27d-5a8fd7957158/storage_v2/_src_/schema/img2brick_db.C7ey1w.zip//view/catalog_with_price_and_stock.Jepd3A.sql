create definer = root@localhost view catalog_with_price_and_stock as
select min(`C`.`id_catalogue`)                                       AS `id_catalogue`,
       `C`.`height`                                                  AS `height`,
       `C`.`width`                                                   AS `width`,
       `C`.`color_hex`                                               AS `color_hex`,
       `C`.`color_name`                                              AS `color_name`,
       `C`.`holes`                                                   AS `holes`,
       `calculate_brick_price`(0.01, 0.9, `C`.`width`, `C`.`height`) AS `unit_price`,
       count(`I`.`id_inventory`)                                     AS `stock`
from (`img2brick_db`.`CATALOG` `C` left join `img2brick_db`.`INVENTORY` `I`
      on (`C`.`id_catalogue` = `I`.`id_catalogue`))
where `I`.`pavage_id` is null
group by `C`.`height`, `C`.`width`, `C`.`color_hex`, `C`.`color_name`, `C`.`holes`;

