create definer = root@`%` event check_users_inactivitie_after_3_years on schedule
    every '3' YEAR
        starts '2026-01-01 00:00:00'
    enable
    do
    BEGIN
    CALL delete_inactivitie_users();
END;

