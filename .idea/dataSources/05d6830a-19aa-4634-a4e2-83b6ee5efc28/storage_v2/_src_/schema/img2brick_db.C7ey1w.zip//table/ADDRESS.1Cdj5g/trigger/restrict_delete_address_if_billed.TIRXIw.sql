create definer = root@localhost trigger restrict_delete_address_if_billed
    before delete
    on ADDRESS
    for each row
BEGIN
	DECLARE bill_created_at DATETIME;
    SELECT created_at INTO bill_created_at
    FROM ORDER_BILL
    WHERE address_id = OLD.address_id;
	IF @disable_triggers IS NULL OR @disable_triggers = 0 THEN
        IF bill_created_at IS NOT NULL THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Delete an address is prohibited because the associated order has been finalized.';
        END IF;
    END IF;
END;

