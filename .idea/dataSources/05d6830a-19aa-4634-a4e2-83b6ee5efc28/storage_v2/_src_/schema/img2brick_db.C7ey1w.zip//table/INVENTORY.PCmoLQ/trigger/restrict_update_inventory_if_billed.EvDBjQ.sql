create definer = root@localhost trigger restrict_update_inventory_if_billed
    before update
    on INVENTORY
    for each row
BEGIN
    DECLARE bill_date DATETIME;
    SELECT created_at INTO bill_date
    FROM ORDER_BILL
    JOIN contain ON contain.order_id = ORDER_BILL.order_id
    WHERE contain.pavage_id = NEW.pavage_id;
    IF @disable_triggers IS NULL OR @disable_triggers = 0 THEN
        IF bill_date IS NOT NULL THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Cannot be associated with a finalised order.';
        END IF;
    END IF;
END;

