create definer = root@localhost trigger restrict_delete_inventory_if_billed
    before delete
    on INVENTORY
    for each row
BEGIN 
	IF @disable_triggers IS NULL OR @disable_triggers = 0 THEN
        IF OLD.pavage_id IS NOT NULL THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Delete inventory is prohibited because the associated order has been finalized.';
        END IF;
    END IF;
END;

