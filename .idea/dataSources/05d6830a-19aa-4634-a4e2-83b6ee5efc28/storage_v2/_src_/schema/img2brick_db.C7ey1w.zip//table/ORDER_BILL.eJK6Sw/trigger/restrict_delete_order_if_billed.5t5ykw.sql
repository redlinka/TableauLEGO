create definer = root@localhost trigger restrict_delete_order_if_billed
    before delete
    on ORDER_BILL
    for each row
BEGIN
    IF @disable_triggers IS NULL OR @disable_triggers = 0 THEN
        IF OLD.created_at IS NOT NULL THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Delete an finalised order is prohibited.';
        END IF;
    END IF;	
END;

