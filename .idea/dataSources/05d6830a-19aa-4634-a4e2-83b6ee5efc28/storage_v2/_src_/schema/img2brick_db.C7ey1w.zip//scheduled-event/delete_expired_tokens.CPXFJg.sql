create definer = dev@`%` event delete_expired_tokens on schedule
    every '1' MINUTE
        starts '2026-01-11 16:33:41'
    enable
    do
    BEGIN
    DELETE FROM `2FA`
    WHERE token_expire_at < NOW();
END;

