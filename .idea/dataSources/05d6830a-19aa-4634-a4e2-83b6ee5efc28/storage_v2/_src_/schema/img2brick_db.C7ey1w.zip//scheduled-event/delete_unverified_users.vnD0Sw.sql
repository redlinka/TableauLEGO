create definer = dev@`%` event delete_unverified_users on schedule
    every '1' DAY
        starts '2026-01-01 00:00:00'
    enable
    do
    BEGIN

    DELETE FROM USER 

    WHERE is_verified = 0

    AND created_at < NOW() - INTERVAL 1 DAY;

END;

